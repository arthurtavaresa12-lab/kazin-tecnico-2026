# Kazin Técnico 2026 — Build na nuvem pelo celular

Este projeto foi preparado para ser colocado em um repositório GitHub e compilado automaticamente pelo GitHub Actions, sem Android Studio.

## Pelo celular
1. Crie um repositório no GitHub.
2. Envie todos os arquivos desta pasta para o repositório, preservando `.github/workflows`.
3. Abra a aba **Actions** do repositório.
4. Execute **Build Android — APK e AAB**.
5. Quando terminar, abra a execução e baixe os artefatos.

O APK de debug serve para testar no celular.
O AAB de release é o pacote de publicação, mas precisa ser assinado com uma chave de upload antes de ser enviado ao Google Play.

O projeto usa targetSdk 36, exigido para novos apps e atualizações no Google Play desde 31/08/2026.
