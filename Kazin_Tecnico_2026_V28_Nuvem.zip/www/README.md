# Kazin Técnico 2026 — V19

Correção principal: o Mercado de Transferências agora mantém todos os jogadores cadastrados no banco de dados disponíveis para pesquisa, em vez de limitar a lista a 28 jogadores sorteados.

- Pesquisa por nome, clube ou posição.
- Pesquisa ignora acentos (ex.: "Hugo" encontra "Hugo", e nomes acentuados também são localizados sem acento).
- Mantidas contratação, empréstimo, propostas e demais recursos da V18.
